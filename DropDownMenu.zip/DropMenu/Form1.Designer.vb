﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.HeaderMenu = New System.Windows.Forms.Panel()
        Me.MainMenu = New System.Windows.Forms.Panel()
        Me.DropPanel2 = New System.Windows.Forms.Panel()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.DropButton2 = New System.Windows.Forms.Button()
        Me.DropPanel1 = New System.Windows.Forms.Panel()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.DropButton1 = New System.Windows.Forms.Button()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Label1 = New System.Windows.Forms.Label()
        Me.HeaderMenu.SuspendLayout()
        Me.MainMenu.SuspendLayout()
        Me.DropPanel2.SuspendLayout()
        Me.DropPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'HeaderMenu
        '
        Me.HeaderMenu.BackColor = System.Drawing.Color.FromArgb(CType(CType(41, Byte), Integer), CType(CType(57, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.HeaderMenu.Controls.Add(Me.Label1)
        Me.HeaderMenu.Dock = System.Windows.Forms.DockStyle.Top
        Me.HeaderMenu.Location = New System.Drawing.Point(0, 0)
        Me.HeaderMenu.Name = "HeaderMenu"
        Me.HeaderMenu.Size = New System.Drawing.Size(819, 38)
        Me.HeaderMenu.TabIndex = 0
        '
        'MainMenu
        '
        Me.MainMenu.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(111, Byte), Integer))
        Me.MainMenu.Controls.Add(Me.DropPanel2)
        Me.MainMenu.Controls.Add(Me.DropPanel1)
        Me.MainMenu.Dock = System.Windows.Forms.DockStyle.Right
        Me.MainMenu.Location = New System.Drawing.Point(569, 38)
        Me.MainMenu.Name = "MainMenu"
        Me.MainMenu.Size = New System.Drawing.Size(250, 430)
        Me.MainMenu.TabIndex = 1
        '
        'DropPanel2
        '
        Me.DropPanel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(111, Byte), Integer))
        Me.DropPanel2.Controls.Add(Me.Button5)
        Me.DropPanel2.Controls.Add(Me.Button6)
        Me.DropPanel2.Controls.Add(Me.Button7)
        Me.DropPanel2.Controls.Add(Me.Button8)
        Me.DropPanel2.Controls.Add(Me.DropButton2)
        Me.DropPanel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.DropPanel2.Location = New System.Drawing.Point(0, 210)
        Me.DropPanel2.MaximumSize = New System.Drawing.Size(250, 210)
        Me.DropPanel2.MinimumSize = New System.Drawing.Size(250, 50)
        Me.DropPanel2.Name = "DropPanel2"
        Me.DropPanel2.Size = New System.Drawing.Size(250, 210)
        Me.DropPanel2.TabIndex = 3
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.FromArgb(CType(CType(77, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.Button5.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button5.FlatAppearance.BorderSize = 0
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.ForeColor = System.Drawing.Color.White
        Me.Button5.Location = New System.Drawing.Point(0, 170)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(250, 40)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "Button5"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.FromArgb(CType(CType(77, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.Button6.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button6.FlatAppearance.BorderSize = 0
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.ForeColor = System.Drawing.Color.White
        Me.Button6.Location = New System.Drawing.Point(0, 130)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(250, 40)
        Me.Button6.TabIndex = 3
        Me.Button6.Text = "Button6"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.FromArgb(CType(CType(77, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.Button7.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button7.FlatAppearance.BorderSize = 0
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.ForeColor = System.Drawing.Color.White
        Me.Button7.Location = New System.Drawing.Point(0, 90)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(250, 40)
        Me.Button7.TabIndex = 2
        Me.Button7.Text = "Button7"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.FromArgb(CType(CType(77, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.Button8.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button8.FlatAppearance.BorderSize = 0
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.ForeColor = System.Drawing.Color.White
        Me.Button8.Location = New System.Drawing.Point(0, 50)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(250, 40)
        Me.Button8.TabIndex = 1
        Me.Button8.Text = "Button8"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'DropButton2
        '
        Me.DropButton2.Dock = System.Windows.Forms.DockStyle.Top
        Me.DropButton2.FlatAppearance.BorderSize = 0
        Me.DropButton2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.DropButton2.ForeColor = System.Drawing.Color.White
        Me.DropButton2.Image = Global.DropDown_Menu.My.Resources.Resources.Arrow_Left
        Me.DropButton2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.DropButton2.Location = New System.Drawing.Point(0, 0)
        Me.DropButton2.Name = "DropButton2"
        Me.DropButton2.Padding = New System.Windows.Forms.Padding(5, 0, 0, 0)
        Me.DropButton2.Size = New System.Drawing.Size(250, 50)
        Me.DropButton2.TabIndex = 0
        Me.DropButton2.Text = "DropButton2"
        Me.DropButton2.UseVisualStyleBackColor = True
        '
        'DropPanel1
        '
        Me.DropPanel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(54, Byte), Integer), CType(CType(78, Byte), Integer), CType(CType(111, Byte), Integer))
        Me.DropPanel1.Controls.Add(Me.Button4)
        Me.DropPanel1.Controls.Add(Me.Button3)
        Me.DropPanel1.Controls.Add(Me.Button2)
        Me.DropPanel1.Controls.Add(Me.Button1)
        Me.DropPanel1.Controls.Add(Me.DropButton1)
        Me.DropPanel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.DropPanel1.Location = New System.Drawing.Point(0, 0)
        Me.DropPanel1.MaximumSize = New System.Drawing.Size(250, 210)
        Me.DropPanel1.MinimumSize = New System.Drawing.Size(250, 50)
        Me.DropPanel1.Name = "DropPanel1"
        Me.DropPanel1.Size = New System.Drawing.Size(250, 210)
        Me.DropPanel1.TabIndex = 2
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.FromArgb(CType(CType(77, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.Button4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button4.FlatAppearance.BorderSize = 0
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.ForeColor = System.Drawing.Color.White
        Me.Button4.Location = New System.Drawing.Point(0, 170)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(250, 40)
        Me.Button4.TabIndex = 4
        Me.Button4.Text = "Button4"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.FromArgb(CType(CType(77, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.Button3.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button3.FlatAppearance.BorderSize = 0
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(0, 130)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(250, 40)
        Me.Button3.TabIndex = 3
        Me.Button3.Text = "Button3"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(77, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.Button2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button2.FlatAppearance.BorderSize = 0
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(0, 90)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(250, 40)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "Button2"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(77, Byte), Integer), CType(CType(96, Byte), Integer), CType(CType(130, Byte), Integer))
        Me.Button1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(0, 50)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(250, 40)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'DropButton1
        '
        Me.DropButton1.Dock = System.Windows.Forms.DockStyle.Top
        Me.DropButton1.FlatAppearance.BorderSize = 0
        Me.DropButton1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.DropButton1.ForeColor = System.Drawing.Color.White
        Me.DropButton1.Image = Global.DropDown_Menu.My.Resources.Resources.Arrow_Left
        Me.DropButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.DropButton1.Location = New System.Drawing.Point(0, 0)
        Me.DropButton1.Name = "DropButton1"
        Me.DropButton1.Padding = New System.Windows.Forms.Padding(5, 0, 0, 0)
        Me.DropButton1.Size = New System.Drawing.Size(250, 50)
        Me.DropButton1.TabIndex = 0
        Me.DropButton1.Text = "DropButton1"
        Me.DropButton1.UseVisualStyleBackColor = True
        '
        'Timer1
        '
        Me.Timer1.Interval = 15
        '
        'Timer2
        '
        Me.Timer2.Interval = 15
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(214, 21)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "DropDown Menu Example"
        '
        'Form1
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(819, 468)
        Me.Controls.Add(Me.MainMenu)
        Me.Controls.Add(Me.HeaderMenu)
        Me.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "DropDown Menu Example"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.HeaderMenu.ResumeLayout(False)
        Me.HeaderMenu.PerformLayout()
        Me.MainMenu.ResumeLayout(False)
        Me.DropPanel2.ResumeLayout(False)
        Me.DropPanel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents HeaderMenu As Panel
    Friend WithEvents MainMenu As Panel
    Friend WithEvents DropPanel1 As Panel
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents DropButton1 As Button
    Friend WithEvents DropPanel2 As Panel
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents DropButton2 As Button
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents Label1 As Label
End Class
